import React, { useState, useEffect } from "react";

const VoiceToText = () => {
  const [transcript, setTranscript] = useState("");
  const [listening, setListening] = useState(false);

  useEffect(() => {
    // Check if the browser supports the SpeechRecognition API
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    // const SpeechSynthesis =window.SpeechSynthesis
    const constraints = {
      audio: {
        noiseSuppression: true // Enable noise suppression
      }
    };
    navigator.mediaDevices.getUserMedia(constraints)
    .then((stream) => {
      // Do something with the stream if necessary
      let audio = document.createElement('audio');
      audio.srcObject = stream;
      audio.play();
      let audioContext = new AudioContext();
      let source = audioContext.createMediaStreamSource(stream);
    })
    .catch((error) => {
      console.error('Error accessing the microphone', error);
    });
    if (SpeechRecognition) {
      // Create an instance of SpeechRecognition
      const recognition = new SpeechRecognition();

      recognition.continuous = true; // Keep listening even after the speech has paused

      recognition.lang = "en-US";
      // Define event handlers
      recognition.onstart = () => true;
      recognition.onend = () => setListening(true);
      recognition.onresult = (event) => {
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          interimTranscript += event.results[i][0].transcript;
        }
        setTranscript(interimTranscript);
        console.log(interimTranscript);
      };

      // Start speech recognition
      recognition.start();

      
      // window.speechSynthesis.speak(utterance)
      // Clean up
      return () => {
        recognition.stop();
      };
    } else {
      console.log("Speech recognition not supported in this browser.");
    }
  }, [transcript]);

  function speak() {
    let synth = speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(transcript);
    utterance.lang = "hi-IN";
    // utterance.pitch = 0.8
    // utterance.volume=1.5
    // utterance.rate=.8
    return synth.speak(utterance);
  }

  return (
    <div>
      <p>Microphone: {listening ? "on" : "off"}</p>
      <button onClick={() => setTranscript("")}>Reset</button>
      <button onClick={speak}>speak</button>
      <p>Transcript: {transcript}</p>
    </div>
  );
};

export default VoiceToText;
