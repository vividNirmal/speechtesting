import "./App.css";
import SpeechRecognitionApp from "./compontns/DEmoSpeech";

import VoiceToText from "./compontns/SpeechRecoder";

function App() {
  return <VoiceToText />;
}

export default App;
